module Main where

import Graphics.Gloss

main :: IO ()
main = do
   display (InWindow "seis window" (90,90)) white (Circle 9)
